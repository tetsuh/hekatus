#include "/source/tt_metal/fabric/impl/kernels/edm_fabric/fabric_erisc_router.cpp"
