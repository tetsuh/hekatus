#include "/source/tt_metal/impl/dispatch/kernels/cq_dispatch.cpp"
