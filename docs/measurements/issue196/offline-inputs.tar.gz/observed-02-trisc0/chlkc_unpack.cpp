#define TRISC_UNPACK
#include "defines_generated.h"
#include "/source/tt_metal/impl/dispatch/kernels/cq_dispatch_subordinate_compute.cpp"
