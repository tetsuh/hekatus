#include "/source/tt_metal/impl/dispatch/kernels/cq_prefetch.cpp"
